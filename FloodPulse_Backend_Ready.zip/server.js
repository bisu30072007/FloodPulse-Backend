const express = require("express");
const cors = require("cors");
const twilio = require("twilio");
require("dotenv").config();
const app = express();
app.use(cors()); app.use(express.json());
const PORT = process.env.PORT || 3000;
function missing(){ return ["TWILIO_ACCOUNT_SID","TWILIO_AUTH_TOKEN","TWILIO_PHONE_NUMBER"].filter(k=>!process.env[k]); }
app.get("/api/health",(req,res)=>{const m=missing();res.status(m.length?503:200).json({ok:!m.length,service:"FloodPulse SMS Backend",twilioConfigured:!m.length,missing:m});});
app.post("/api/send-sms",async(req,res)=>{const m=missing(); if(m.length)return res.status(503).json({ok:false,error:"SMS backend is not configured",missing:m}); const {to,message}=req.body||{}; if(!to||!/^\+[1-9]\d{7,14}$/.test(String(to)))return res.status(400).json({ok:false,error:"Invalid recipient number. Use E.164 format, e.g. +919876543210"}); if(!message||!String(message).trim())return res.status(400).json({ok:false,error:"Message is required"}); try{const client=twilio(process.env.TWILIO_ACCOUNT_SID,process.env.TWILIO_AUTH_TOKEN);const r=await client.messages.create({body:String(message).trim().slice(0,1600),from:process.env.TWILIO_PHONE_NUMBER,to:String(to)});res.json({ok:true,message:"SMS accepted by Twilio",sid:r.sid,status:r.status});}catch(e){res.status(502).json({ok:false,error:e.message,code:e.code||null});}});
app.listen(PORT,()=>console.log(`FloodPulse backend running on ${PORT}`));
